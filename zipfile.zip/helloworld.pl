#!/usr/bin/perl 

# Modules used 
use strict; 
use warnings; 
  
# Print function  
print("Hello World\n");

print("$Id: 4a17d6fe9618f967f4d8c81baa9b38bf1f17cffd $");

print("\nHello World\n");

print("Last commit date: Fri Oct 2 14:56:39 2020 +0200 by Krisztian Szep");


# Last commit date: Fri Oct 2 14:56:39 2020 +0200 by Krisztian Szep